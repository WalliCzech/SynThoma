# apps/web

Next.js 14 + TS klient. Zde žije neon, glitch a ostatní radosti, co ničí zraky QA.

- App Router
- MUI, Zustand, React Query, Framer Motion
- Téma a efekty v `src/styles/theme.ts` a `src/styles/effects.css`
