"use client";

import { useEffect } from "react";

declare global {
  interface Window {
    animationManager?: { toggleAll: () => void };
    setTheme?: (name: string) => void;
    __synthomaAudio?: HTMLAudioElement;
    audioPanelPlay?: (file?: string) => void;
    audioPanelEnsurePlaying?: () => void;
    startShinning?: () => void;
    stopShinning?: () => void;
    startGlitchBg?: () => void;
    stopGlitchBg?: () => void;
    startVideoRotation?: () => void;
    stopVideoRotation?: () => void;
    startNoise?: () => void;
    stopNoise?: () => void;
    __cpBootedOnce?: boolean;
    __cpDelegationAttached?: boolean; // legacy
    __cpPanelDelegationAttached?: boolean;
    __cpActionsDelegationAttached?: boolean;
  }
}

export default function ControlPanelClient() {
  useEffect(() => {
    // Nepoužívej tvrdý guard, HMR může DOM vyměnit a listenery zaniknou.
    // Místo toho použijeme delegaci na document (přidána jen jednou níže).
    const root = document.documentElement;
    const body = document.body;

    // Animation manager exposed on window
    window.animationManager = window.animationManager || {
      toggleAll: function () {
        const disabled = localStorage.getItem("animationsDisabled") === "true";
        const next = !disabled;
        localStorage.setItem("animationsDisabled", String(next));
        body.classList.toggle("no-animations", next);
        // update glitch/video helpers
        if (typeof window.stopGlitchBg === "function" && next) window.stopGlitchBg();
        if (typeof window.startGlitchBg === "function" && !next) window.startGlitchBg();
        if (typeof window.stopVideoRotation === "function" && next) window.stopVideoRotation();
        if (typeof window.startVideoRotation === "function" && !next) window.startVideoRotation();
        if (typeof window.stopNoise === "function" && next) window.stopNoise();
        if (typeof window.startNoise === "function" && !next) window.startNoise();
        if (typeof window.stopShinning === "function" && next) window.stopShinning();
        if (typeof window.startShinning === "function" && !next) window.startShinning();
        // hard pause/resume all background videos
        const vids = document.querySelectorAll<HTMLVideoElement>(".video-background video");
        vids.forEach((v) => {
          try {
            if (next) {
              v.pause();
            } else {
              v.play().catch(() => { /* ignore */ });
            }
          } catch {}
        });
        // Button label update
        const btn = document.getElementById("toggle-animations");
        // Když jsou animace vypnuté (next=true), ukaž "Vypnuty"
        if (btn) btn.textContent = next ? "Animace: Vypnuty" : "Animace: Zapnuty";
      },
    };

    function initPersisted() {
      try {
        const areDisabled = localStorage.getItem("animationsDisabled") === "true";
        body.classList.toggle("no-animations", areDisabled);
        if (areDisabled) {
          if (typeof window.stopGlitchBg === "function") window.stopGlitchBg();
          if (typeof window.stopVideoRotation === "function") window.stopVideoRotation();
          if (typeof window.stopNoise === "function") window.stopNoise();
          if (typeof window.stopShinning === "function") window.stopShinning();
          const vids0 = document.querySelectorAll<HTMLVideoElement>(".video-background video");
          vids0.forEach((v) => {
            try {
              v.pause();
            } catch {}
          });
        } else {
          if (typeof window.startGlitchBg === "function") window.startGlitchBg();
          if (typeof window.startVideoRotation === "function") window.startVideoRotation();
          if (typeof window.startNoise === "function") window.startNoise();
          if (typeof window.startShinning === "function") window.startShinning();
        }
        const fs = localStorage.getItem("fontSizeMultiplier");
        if (fs) root.style.setProperty("--font-size-multiplier", fs);
        const op = localStorage.getItem("readerBgOpacity");
        if (op) root.style.setProperty("--reader-bg-opacity", op);
        // Glass mode
        const isGlass = localStorage.getItem("glassMode") === "true";
        body.classList.toggle("glass-mode", isGlass);
        const glassTargets: HTMLElement[] = [];
        try {
          const cp = document.getElementById("control-panel");
          if (cp) glassTargets.push(cp);
          // Správně: čtečka má třídu .SYNTHOMAREADER (bez .terminal)
          const readerEl = document.querySelector<HTMLElement>(".SYNTHOMAREADER");
          if (readerEl) glassTargets.push(readerEl);
        } catch {}
        glassTargets.forEach((el) => {
          el.classList.toggle("glass", isGlass);
        });
        const savedBlur = localStorage.getItem("glassBlur") || "12";
        root.style.setProperty("--glass-blur", savedBlur + "px");
      } catch {}
    }

    function applySetting(key: string, value: string, cssVar?: string) {
      try {
        localStorage.setItem(key, value);
      } catch {}
      if (cssVar) root.style.setProperty(cssVar, value);
    }

    function boot() {
      const togglePanelBtn = document.getElementById("toggle-panel-btn");
      const controlPanel = document.getElementById("control-panel");
      const doTogglePanel = (force?: boolean) => {
        if (!controlPanel || !togglePanelBtn) return;
        const wasVisible = controlPanel.classList.contains("visible");
        const next = typeof force === 'boolean' ? force : !wasVisible;
        controlPanel.classList.toggle("visible", next);
        togglePanelBtn.setAttribute("aria-expanded", String(next));
        if (!wasVisible && next) {
          controlPanel.style.opacity = "1";
          controlPanel.style.pointerEvents = "auto";
          controlPanel.style.transform = "none";
        } else if (wasVisible && !next) {
          controlPanel.style.opacity = "";
          controlPanel.style.pointerEvents = "";
          controlPanel.style.transform = "";
        }
        try { console.debug("[ControlPanel] toggle", { expanded: next }); } catch {}
      };
      if (togglePanelBtn && controlPanel) {
        // Delegace pouze jednou, v bubble fázi (třetí parametr undefined)
        if (!window.__cpPanelDelegationAttached) {
          document.addEventListener('click', function(ev){
            const t = ev.target as HTMLElement | null;
            if (!t) return;
            const btn = t.closest('#toggle-panel-btn');
            if (!btn) return;
            try { ev.preventDefault(); } catch {}
            doTogglePanel();
          });
          document.addEventListener('keydown', function(ev: KeyboardEvent){
            if (ev.key === 'Escape') {
              doTogglePanel(false);
            }
          });
          window.__cpPanelDelegationAttached = true;
        }
      } else {
        try { console.warn("[ControlPanel] Nenalezen toggle nebo panel", { hasBtn: !!togglePanelBtn, hasPanel: !!controlPanel }); } catch {}
      }

      // animations
      const toggleAnimationsBtn = document.getElementById("toggle-animations");
      const toggleGlassBtn = document.getElementById("toggle-glass");
      function updateButtonState() {
        const areAnimationsDisabled = localStorage.getItem("animationsDisabled") === "true";
        if (toggleAnimationsBtn){
          toggleAnimationsBtn.textContent = areAnimationsDisabled ? "Animace: Vypnuty" : "Animace: Zapnuty";
          toggleAnimationsBtn.setAttribute('aria-pressed', String(!areAnimationsDisabled));
        }
        const isGlass = localStorage.getItem("glassMode") === "true";
        if (toggleGlassBtn){
          toggleGlassBtn.textContent = isGlass ? "Sklo: Zapnuto" : "Sklo: Vypnuto";
          toggleGlassBtn.setAttribute('aria-pressed', String(isGlass));
        }
      }
      // Přímé listenery nejsou potřeba, delegujeme níže; jen nastav počáteční stav
      if (toggleAnimationsBtn) { updateButtonState(); }
      if (toggleGlassBtn) { updateButtonState(); }

      // 🎛️ NOVÝ SYNCHRONIZOVANÝ SYSTÉM PRO SLIDERY A GLASS MODE
      
      // 📊 Centrální stav pro glass mode a slidery
      let currentGlassMode = localStorage.getItem('glassMode') === 'true';
      let currentOpacity = parseFloat(localStorage.getItem("readerBgOpacity") || "0.8");
      let currentBlur = parseInt(localStorage.getItem("glassBlur") || "12");
      
      // 🔧 Funkce pro aplikaci glass mode (ČISTÉ CSS ŘEŠENÍ)
      function applyGlassMode(isGlass: boolean, updateSlider: boolean = true) {
        currentGlassMode = isGlass;
        
        console.log(`🔮 Switching to ${isGlass ? 'GLASS' : 'NORMAL'} mode... Time to make things ${isGlass ? 'blurry like my vision after coding 12 hours straight' : 'solid like my commitment issues'} 😵‍💫`);
        
        // Aktualizuj body class
        body.classList.toggle('glass-mode', isGlass);
        
        // Najdi čtečku
        const reader = document.querySelector('.SYNTHOMAREADER') as HTMLElement;
        
        if (isGlass) {
          // 🔮 GLASS MODE: Aplikuj .glass třídu na čtečku
          if (reader) {
            reader.classList.add('glass');
            console.log(`💀 Reader glass class applied - "CSS dělá magii, já jen koukám" ✨`);
          }
          
          // Nastav CSS proměnnou pro blur
          root.style.setProperty("--glass-blur", `${currentBlur}px`);
          console.log(`🎚️ Glass blur set to ${currentBlur}px - "CSS proměnné jsou jako dobré víno, čím starší, tím lepší" 🍷`);
          
        } else {
          // 🎨 NORMAL MODE: Odstraň .glass třídu a nastav opacity
          if (reader) {
            reader.classList.remove('glass');
            reader.style.backgroundColor = `rgba(var(--bg-secondary-rgb), ${currentOpacity})`;
            console.log(`💀 Normal mode applied: opacity ${currentOpacity} - "Zpět k realitě, jako když se probudíš z kódovacího snu" 😴`);
          }
          
          // Nastav CSS proměnnou pro reader opacity
          root.style.setProperty("--reader-bg-opacity", currentOpacity.toString());
        }
        
        // 🎚️ Synchronizuj slider s aktuálním módem
        const opacitySlider = document.getElementById("opacity-slider") as HTMLInputElement | null;
        if (opacitySlider && updateSlider) {
          if (isGlass) {
            // Slider reprezentuje blur (0-24px → 0-1)
            opacitySlider.value = (currentBlur / 24).toString();
            console.log(`🎚️ Slider sync: blur mode, value=${opacitySlider.value} - "Slider teď ovládá blur jako DJ ovládá beat" 🎧`);
          } else {
            // Slider reprezentuje opacity (0-1)
            opacitySlider.value = currentOpacity.toString();
            console.log(`🎚️ Slider sync: opacity mode, value=${opacitySlider.value} - "Slider teď ovládá průhlednost jako ghost ovládá strach" 👻`);
          }
        }
        
        // 🔄 Aktualizuj text tlačítka
        const toggleGlassBtn = document.getElementById("toggle-glass");
        if (toggleGlassBtn) {
          toggleGlassBtn.textContent = isGlass ? "Sklo: Zapnuto" : "Sklo: Vypnuto";
          toggleGlassBtn.setAttribute('aria-pressed', String(isGlass));
          console.log(`🔘 Button updated: "${toggleGlassBtn.textContent}" - "Tlačítko je teď synchronizované jako Swiss hodinky" ⌚`);
        }
        
        // Ulož do localStorage
        try {
          localStorage.setItem('glassMode', String(isGlass));
          console.log(`💾 Glass mode ${isGlass ? 'ENABLED' : 'DISABLED'} saved - "LocalStorage si to pamatuje lépe než já své heslo" 🧠`);
        } catch (e) {
          console.error("💥 Error saving glass mode - LocalStorage odmítá spolupracovat jako můj kód v pondělí ráno:", e);
        }
      }
      
      // 🎚️ Font size slider
      const fontSizeSlider = document.getElementById("font-size-slider") as HTMLInputElement | null;
      if (fontSizeSlider) {
        const savedFontSize = localStorage.getItem("fontSizeMultiplier") || "1";
        fontSizeSlider.value = savedFontSize;
        root.style.setProperty("--font-size-multiplier", savedFontSize);
        fontSizeSlider.addEventListener("input", function (e) {
          const target = e.target as HTMLInputElement;
          applySetting("fontSizeMultiplier", target.value, "--font-size-multiplier");
        });
      }
      
      // 🎚️ Opacity/Blur slider (inteligentní)
      const opacitySlider = document.getElementById("opacity-slider") as HTMLInputElement | null;
      if (opacitySlider) {
        // 🚀 DŮLEŽITÉ: Aplikuj glass mode při inicializaci
        console.log(`🔄 Initializing glass mode: ${currentGlassMode} - "Čas aplikovat magii při startu!" ✨`);
        applyGlassMode(currentGlassMode, true);
        
        opacitySlider.addEventListener("input", function (e) {
          const target = e.target as HTMLInputElement;
          const val = parseFloat(target.value);
          
          console.log(`🎚️ Slider moved to ${val} - "Někdo si hraje se sliderem jako dítě s hračkou" 🎮`);
          
          if (currentGlassMode) {
            // 🔮 GLASS MODE: slider mění --glass-blur CSS proměnnou
            currentBlur = Math.round(val * 24); // 0-1 → 0-24px
            
            // 🎯 ČISTÉ ŘEŠENÍ: Jen nastav CSS proměnnou, .glass třída udělá zbytek
            root.style.setProperty("--glass-blur", `${currentBlur}px`);
            
            try {
              localStorage.setItem("glassBlur", String(currentBlur));
              console.log(`💀 Glass blur saved: ${currentBlur}px - "CSS proměnné jsou jako dobré víno, čím starší, tím lepší" 🍷`);
            } catch (e) {
              console.error("💥 Error saving blur - LocalStorage má horší paměť než já po kávě:", e);
            }
            
          } else {
            // 🎨 NORMAL MODE: slider mění opacity
            currentOpacity = val;
            
            root.style.setProperty("--reader-bg-opacity", val.toString());
            
            const reader = document.querySelector('.SYNTHOMAREADER') as HTMLElement;
            if (reader) {
              reader.style.backgroundColor = `rgba(var(--bg-secondary-rgb), ${val})`;
            }
            
            try {
              localStorage.setItem("readerBgOpacity", val.toString());
              console.log(`💀 Background opacity saved: ${val} - "Průhlednost level: ${val > 0.8 ? 'Solid as my excuses' : val > 0.5 ? 'Semi-transparent like my intentions' : 'Ghost mode activated'}" 👻`);
            } catch (e) {
              console.error("💥 Error saving opacity - Saving failed harder than my last relationship:", e);
            }
          }
        });
      }

      // theme buttons
      const themeButtons = document.querySelectorAll<HTMLButtonElement>(".theme-button");
      if (themeButtons.length) {
        const savedTheme = localStorage.getItem("theme") || "synthoma";
        body.setAttribute("data-theme", savedTheme);
        try { document.documentElement.setAttribute('data-theme', savedTheme); } catch {}
        themeButtons.forEach((button) => {
          button.addEventListener("click", function () {
            const theme = button.getAttribute("data-theme");
            if (!theme) return;
            if (typeof window.setTheme === "function") window.setTheme(theme);
            else {
              body.setAttribute("data-theme", theme);
              try { document.documentElement.setAttribute('data-theme', theme); } catch {}
            }
            try {
              localStorage.setItem("theme", theme);
            } catch {}
            themeButtons.forEach((b) => {
              b.classList.toggle("active", b.getAttribute("data-theme") === theme);
            });
            // Po změně motivu znovu spusť video rotaci a pokus se přehrát videa (některé prohlížeče pauznou)
            try { if (typeof window.startVideoRotation === 'function') window.startVideoRotation(); } catch {}
            try {
              document.querySelectorAll<HTMLVideoElement>('.video-background video').forEach(v => {
                try { v.play().catch(()=>{}); } catch {}
              });
            } catch {}
          });
        });
        themeButtons.forEach((b) => {
          b.classList.toggle("active", b.getAttribute("data-theme") === savedTheme);
        });
      }

      // audio
      const playlistContainer = document.getElementById("playlist-container");
      const playPauseBtn = document.getElementById("play-pause-btn");
      const stopBtn = document.getElementById("stop-btn");
      const progressBar = document.getElementById("progress-bar") as HTMLDivElement | null;
      const progressBarContainer = document.getElementById("progress-bar-container");
      const audioTracks = [
        { title: "SynthBachmoff", file: "/audio/SynthBachmoff.mp3" },
        { title: "Glitch Ambient", file: "/audio/SYNTHOMA1.mp3" },
        { title: "Nuova", file: "/audio/Nuova.mp3" },
      ];
      let currentTrackIndex = -1;
      // Vytvoř/skonfiguruj sdílený <audio> a připevni do DOM (některé prohlížeče jsou cimprlich)
      let audio = window.__synthomaAudio ? window.__synthomaAudio : new Audio();
      audio.preload = 'auto';
      audio.controls = false;
      audio.setAttribute('playsinline', 'true');
      try {
        if (!document.getElementById('synthoma-audio')) {
          const holder = document.createElement('div');
          holder.id = 'synthoma-audio';
          holder.style.position = 'fixed';
          holder.style.inset = 'auto auto -9999px -9999px'; // nenápadně mimo viewport
          holder.style.width = '1px'; holder.style.height = '1px'; holder.style.overflow = 'hidden';
          holder.appendChild(audio);
          document.body.appendChild(holder);
        } else {
          const holder = document.getElementById('synthoma-audio');
          if (holder && !holder.contains(audio)) holder.appendChild(audio);
        }
      } catch {}
      if (!window.__synthomaAudio) {
        window.__synthomaAudio = audio;
      }
      function playAudio(filePath?: string) {
        if (filePath) {
          audio.src = filePath;
          try { audio.load(); } catch {}
        }
        const doPlay = () => audio.play().catch(() => { /* ignore */ });
        // Pokud ještě není připravené bufferování, počkej na canplaythrough (méně “klik a nic”)
        if (audio.readyState < 3) {
          const onReady = () => { try { audio.removeEventListener('canplaythrough', onReady); } catch {} doPlay(); };
          try { audio.addEventListener('canplaythrough', onReady, { once: true }); } catch { doPlay(); }
        } else {
          doPlay();
        }
        if (playPauseBtn) playPauseBtn.textContent = "⏸️";
      }
      function updatePlaylistActiveState() {
        const items = document.querySelectorAll<HTMLAnchorElement>("#playlist-container a");
        items.forEach((item, index) => {
          item.classList.toggle("active", index === currentTrackIndex);
        });
      }
      function playNextTrack() {
        if (!audioTracks.length) return;
        currentTrackIndex = (currentTrackIndex + 1) % audioTracks.length;
        const track = audioTracks[currentTrackIndex];
        playAudio(track.file);
        updatePlaylistActiveState();
      }
      function playPrevTrack() {
        if (!audioTracks.length) return;
        currentTrackIndex = (currentTrackIndex - 1 + audioTracks.length) % audioTracks.length;
        const track = audioTracks[currentTrackIndex];
        playAudio(track.file);
        updatePlaylistActiveState();
      }
      if (playlistContainer) {
        // Vyčisti staré položky při re-initu (HMR)
        try { (playlistContainer as HTMLElement).innerHTML = ''; } catch {}
        audioTracks.forEach((track, index) => {
          const trackElement = document.createElement("a");
          trackElement.href = "#";
          trackElement.textContent = track.title;
          (trackElement as any).dataset.index = String(index);
          trackElement.addEventListener("click", function (e) {
            e.preventDefault();
            currentTrackIndex = index;
            playAudio(track.file);
            updatePlaylistActiveState();
          });
          playlistContainer.appendChild(trackElement);
        });
      }
      // ZÁMĚRNĚ: Necháváme pouze delegovanou obsluhu (níže), aby se klik nevyhodnotil 2× a nestřelil se do nohy.
      audio.addEventListener("timeupdate", function () {
        if (progressBar && audio.duration) {
          const progress = (audio.currentTime / audio.duration) * 100;
          progressBar.style.width = progress + "%";
        }
      });
      audio.addEventListener("play", function () {
        if (playPauseBtn) { playPauseBtn.textContent = "⏸️"; playPauseBtn.setAttribute('aria-pressed','true'); }
      });
      audio.addEventListener("pause", function () {
        if (playPauseBtn) { playPauseBtn.textContent = "▶️"; playPauseBtn.setAttribute('aria-pressed','false'); }
      });
      audio.addEventListener("error", function(){
        try { console.warn('[Audio] Chyba přehrávání, přeskakuji na další skladbu'); } catch {}
        // zkus další skladbu, ať se UI necítí jak ve výtahu bez hudby
        playNextTrack();
      });
      if (progressBarContainer) {
        progressBarContainer.addEventListener("click", function (e: MouseEvent) {
          if (!audio.duration) return;
          const rect = (progressBarContainer as HTMLElement).getBoundingClientRect();
          const clickX = e.clientX - rect.left;
          audio.currentTime = (clickX / rect.width) * audio.duration;
        });
      }
      audio.addEventListener("ended", playNextTrack);

      // Delegace kliknutí pro audio ovladače (robustní proti HMR a reflow)
      if (!(window as any).__cpAudioDelegationAttached) {
        document.addEventListener('click', function(ev){
          const t = ev.target as HTMLElement | null;
          if (!t) return;
          const btn = t.closest('button');
          if (!btn) return;
          if (btn.id === 'play-pause-btn'){
            try { ev.preventDefault(); ev.stopPropagation(); } catch {}
            try { console.debug('[Audio] play/pause click; paused=', audio.paused, 'src=', !!audio.src); } catch {}
            if (audio.paused) {
              if (audio.src) {
                audio.play().catch(() => {});
              } else {
                // žádný src? Nakopni playlist od začátku
                currentTrackIndex = -1;
                playNextTrack();
              }
            } else {
              audio.pause();
            }
          } else if (btn.id === 'stop-btn'){
            try { ev.preventDefault(); ev.stopPropagation(); } catch {}
            try { console.debug('[Audio] stop click'); } catch {}
            audio.pause();
            audio.currentTime = 0;
          }
        }, true);
        (window as any).__cpAudioDelegationAttached = true;
      }

      // 🔘 Event handlers pro tlačítka (s novou glass mode logikou)
      if (!window.__cpActionsDelegationAttached) {
        document.addEventListener('click', function(ev){
          const target = ev.target as HTMLElement | null;
          if (!target) return;
          const btn = target.closest('button');
          if (!btn) return;
          
          if (btn.id === 'toggle-animations') {
            try { ev.preventDefault(); ev.stopPropagation(); } catch {}
            try { console.debug('[ControlPanel] click toggle-animations'); } catch {}
            window.animationManager?.toggleAll();
            try { document.dispatchEvent(new CustomEvent('synthoma:animations-changed')); } catch {}
            updateButtonState();
            
          } else if (btn.id === 'toggle-glass') {
            try { ev.preventDefault(); ev.stopPropagation(); } catch {}
            console.log(`🔘 Glass button clicked - "Někdo chce přepnout mezi realitou a iluzí" ✨`);
            
            // 🔮 Použij nový synchronizovaný systém
            const next = !currentGlassMode;
            console.log(`🔄 Switching from ${currentGlassMode ? 'GLASS' : 'NORMAL'} to ${next ? 'GLASS' : 'NORMAL'} mode - "Plot twist incoming!" 🎭`);
            
            applyGlassMode(next, true);
            
            // updateButtonState už není potřeba - applyGlassMode to dělá
            console.log(`✅ Glass mode toggle complete - "Synchronizace dokončena jako boss fight" 🎮`);
          }
        }, true);
        window.__cpActionsDelegationAttached = true;
      }

      // ⚡ Speed controls pro typewriter
      const speedButtons = document.querySelectorAll<HTMLButtonElement>(".speed-btn");
      const savedSpeed = localStorage.getItem("typewriterSpeed") || "normal";
      
      function updateSpeedButtons(activeSpeed: string) {
        speedButtons.forEach(btn => {
          btn.classList.toggle("active", btn.getAttribute("data-speed") === activeSpeed);
        });
      }
      
      // 🎯 Inicializuj s uloženou hodnotou
      updateSpeedButtons(savedSpeed);
      
      // 🔥 Pošli initial event pro typewriter (pokud není default)
      if (savedSpeed !== "normal") {
        setTimeout(() => {
          document.dispatchEvent(new CustomEvent('synthoma:speed-changed', { 
            detail: { speed: savedSpeed } 
          }));
          console.log(`💀 Initial typewriter speed set to: ${savedSpeed}`);
        }, 100);
      }
      
      speedButtons.forEach(btn => {
        btn.addEventListener("click", function() {
          const speed = btn.getAttribute("data-speed");
          if (!speed) return;
          
          try {
            localStorage.setItem("typewriterSpeed", speed);
            updateSpeedButtons(speed);
            
            // 🔥 Pošli event pro typewriter
            document.dispatchEvent(new CustomEvent('synthoma:speed-changed', { 
              detail: { speed } 
            }));
            
            console.log(`💀 Typewriter speed changed to: ${speed}`);
          } catch (e) {
            console.error("💥 Error setting typewriter speed:", e);
          }
        });
      });

      // Hover micro-interaction
      const hoverElements = document.querySelectorAll<HTMLElement>("[data-hover-text]");
      hoverElements.forEach((element) => {
        element.addEventListener("mouseover", function () {
          element.style.transform = "translateY(-2px)";
        });
        element.addEventListener("mouseout", function () {
          element.style.transform = "translateY(0)";
        });
      });

      initPersisted();
    }

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot);
      return () => document.removeEventListener("DOMContentLoaded", boot);
    } else {
      boot();
    }
    // No teardown for many 1-off listeners; page-level lifetime like before
    return;
  }, []);

  return null;
}
