export type CancelFn = () => void;
export type SpeedMode = 'instant' | 'fast' | 'normal' | 'slow';

// 🚀 Global speed control
let currentSpeed: SpeedMode = 'normal';

function setCurrentSpeed(speed: SpeedMode): void {
  currentSpeed = speed;
  try {
    localStorage.setItem('typewriterSpeed', speed);
  } catch (e) {
    console.warn('💥 Could not save typewriter speed to localStorage:', e);
  }
}

function getCurrentSpeed(): SpeedMode {
  try {
    const saved = localStorage.getItem('typewriterSpeed') as SpeedMode;
    if (saved && ['instant', 'fast', 'normal', 'slow'].includes(saved)) {
      return saved;
    }
  } catch (e) {
    console.warn('💥 Could not load typewriter speed from localStorage:', e);
  }
  return 'normal';
}

// Initialize speed from localStorage
currentSpeed = getCurrentSpeed();

// 🎧 Global listener for speed changes from control panel
const handleSpeedChange = (e: any) => {
  const speed = e.detail?.speed as SpeedMode;
  if (speed) {
    setCurrentSpeed(speed);
    console.log(`💀 Typewriter speed updated from control panel: ${speed}`);
  }
};

// Set up global listener once
if (typeof document !== 'undefined') {
  document.removeEventListener('synthoma:speed-changed', handleSpeedChange);
  document.addEventListener('synthoma:speed-changed', handleSpeedChange);
  console.log('💀 Global speed change listener attached');
}

interface TypewriterOptions {
  text: string;
  host: HTMLElement; // container that has a span.noising-text inside
  getDurationMs?: () => number; // returns the total typing duration from CSS variables
  onStart?: () => void;
  onDone?: () => void;
  speed?: 'slow' | 'normal' | 'fast' | 'instant'; // 🚀 Nová možnost rychlosti
  glitchIntensity?: 'minimal' | 'normal' | 'intense'; // 💀 Intenzita glitch efektů
  enableSound?: boolean; // 🔊 Zvukové efekty (pro budoucnost)
}

// --- Kapitoly: injektuj <style>/<link> z HTML kapitoly do <head> a vrať obsah <body> ---
function absolutizeUrl(raw: string, baseUrl: string): string {
  const url = raw.trim().replace(/^['"]|['"]$/g, '');
  if (!url) return url;
  if (/^(?:[a-z]+:)?\/\//i.test(url)) return url; // http(s): or protocol-relative
  if (/^(?:data:|blob:|about:)/i.test(url)) return url;
  if (url.startsWith('/')) return url; // already root-based
  return baseUrl.replace(/\/[^/]*$/, '/') + url; // ensure trailing slash then append
}

function rewriteCssUrls(cssText: string, baseUrl: string): string {
  return cssText.replace(/url\(([^)]+)\)/gi, (m, p1) => {
    const abs = absolutizeUrl(String(p1), baseUrl);
    return `url(${abs})`;
  }).replace(/@import\s+url\(([^)]+)\)/gi, (m, p1) => {
    const abs = absolutizeUrl(String(p1), baseUrl);
    return `@import url(${abs})`;
  }).replace(/@import\s+['"]([^'\"]+)['"]/gi, (m, p1) => {
    const abs = absolutizeUrl(String(p1), baseUrl);
    return `@import url(${abs})`;
  });
}

function clearPreviousChapterAssets(): void {
  const head = document.head;
  const nodes = Array.from(head.querySelectorAll('[data-chapter-asset="1"]')) as HTMLElement[];
  nodes.forEach(n => { try { n.remove(); } catch {} });
}

function installChapterAssetsAndGetBody(html: string, baseUrl: string, _key: string): string {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const head = document.head;
    // Vyčisti předchozí injekce
    clearPreviousChapterAssets();

    // <link rel="stylesheet"/preload font>
    const links = Array.from(doc.querySelectorAll('link')) as HTMLLinkElement[];
    for (const l of links) {
      const rel = (l.getAttribute('rel') || '').toLowerCase();
      if (!rel) continue;
      if (rel === 'stylesheet' || (rel === 'preload' && (l.getAttribute('as') || '').toLowerCase() === 'font') || rel === 'preconnect') {
        const el = document.createElement('link');
        el.rel = l.rel;
        const href = l.getAttribute('href') || '';
        if (href) el.href = absolutizeUrl(href, baseUrl);
        const asv = l.getAttribute('as'); if (asv) el.as = asv as any;
        const cross = l.getAttribute('crossorigin'); if (cross) el.setAttribute('crossorigin', cross);
        const media = l.getAttribute('media'); if (media) el.media = media;
        el.setAttribute('data-chapter-asset', '1');
        head.appendChild(el);
      }
    }

    // <style> bloky (z headu i body)
    const styles = Array.from(doc.querySelectorAll('style')) as HTMLStyleElement[];
    for (const s of styles) {
      const el = document.createElement('style');
      el.type = s.type || 'text/css';
      el.textContent = rewriteCssUrls(s.textContent || '', baseUrl);
      el.setAttribute('data-chapter-asset', '1');
      head.appendChild(el);
    }

    // Přepiš relativní URL v body (img/src, video/audio/source/src, a[href] na kapitolu)
    const body = doc.body;
    if (body) {
      const rewriteAttr = (el: Element, attr: string) => {
        const val = el.getAttribute(attr);
        if (!val) return;
        el.setAttribute(attr, absolutizeUrl(val, baseUrl));
      };
      body.querySelectorAll('img, video, audio, source, track').forEach((el) => rewriteAttr(el as Element, 'src'));
      body.querySelectorAll('a[href]').forEach((el) => {
        const href = el.getAttribute('href') || '';
        // ponech #anchor a absolutní odkazy
        if (href.startsWith('#') || /^(?:[a-z]+:)?\/\//i.test(href)) return;
        (el as Element).setAttribute('href', absolutizeUrl(href, baseUrl));
      });
      return body.innerHTML;
    }
    return html;
  } catch (e) {
    console.warn('chapter assets install failed', e);
    return html;
  }
}

// --- Externí utilitky pro typewriter na #reader-body ---

function extractTextFromRichHost(host: HTMLElement): string {
  const rich = host.querySelector('.rich-hidden') as HTMLElement | null;
  const normalize = (raw: string) => raw
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/\r\n?/g, '\n');
  if (rich) {
    const rawHtml = rich.innerHTML || '';
    const html2 = normalize(rawHtml);
    let text = html2
      .replace(/<br\s*\/?>(?=\s*\n?)/gi, '\n')
      .replace(/<\/(p|div|h[1-6]|li)>/gi, '</$1>\n')
      .replace(/<li[^>]*>/gi, '• ')
      .replace(/<style[\s\S]*?<\/style>/gi, '')
      .replace(/<script[\s\S]*?<\/script>/gi, '')
      .replace(/<[^>]+>/g, '')
      .replace(/[\t ]+\n/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
    if (!text) text = normalize(rich.textContent || '').trim();
    return text;
  }
  return '';
}

interface Segment {
  text: string;
  classes: string;
  style?: string;
  inline?: boolean;
}

// Vytvoř segmenty z bohatého HTML: rozlož blokové prvky na střídání textových úseků a inline prvků v původním pořadí
function extractSegmentsFromRichHost(host: HTMLElement): Segment[] {
  const rich = host.querySelector('.rich-hidden') as HTMLElement | null;
  if (!rich) return [];
  const out: Segment[] = [];
  const isBlock = (el: Element) => /^(P|DIV|H[1-6]|LI|PRE|BLOCKQUOTE)$/i.test(el.tagName);
  const hasBlockClass = (el: Element) => {
    const cls = el.getAttribute('class') || '';
    return /(\b|_)(log|dialog|text|title)(\b|_)/.test(cls);
  };
  const isBlockLike = (el: Element) => isBlock(el) || hasBlockClass(el) || el.tagName.toUpperCase() === 'LOG';
  const needsOwnSegment = (el: Element) => {
    // Inline element zajímavý stylem nebo třídou (např. span s style/class)
    const tag = el.tagName.toUpperCase();
    if (tag === 'BR') return true;
    const cls = (el.getAttribute('class') || '').trim();
    const sty = (el.getAttribute('style') || '').trim();
    return !!cls || !!sty;
  };
  const normText = (s: string) => s
    .replace(/\u00A0/g, ' ')
    .replace(/\r\n?/g, '\n');

  const flushText = (buf: string, parentEl: Element) => {
    const txt = buf
      .replace(/[\t ]+\n/g, '\n')
      .replace(/\n{3,}/g, '\n\n');
    if (!txt) return;
    const classes = (parentEl.getAttribute('class') || '').trim();
    const style = parentEl.getAttribute('style') || undefined;
    out.push({ text: txt, classes, style, inline: false });
  };

  const pushInline = (el: Element) => {
    const txt = normText((el as HTMLElement).innerText || '');
    if (!txt) return;
    const classes = (el.getAttribute('class') || '').trim();
    const style = el.getAttribute('style') || undefined;
    out.push({ text: txt, classes, style, inline: true });
  };

  const processBlock = (el: Element) => {
    let textBuf = '';
    el.childNodes.forEach((node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        textBuf += normText(node.textContent || '');
        return;
      }
      if (node.nodeType === Node.ELEMENT_NODE) {
        const child = node as Element;
        if (child.tagName.toUpperCase() === 'BR') {
          textBuf += '\n';
          return;
        }
        if (needsOwnSegment(child)) {
          // Nejprve vyprázdni dosavadní plain text z rodiče
          flushText(textBuf, el);
          textBuf = '';
          // Přidej inline segment
          pushInline(child);
          return;
        }
        // Rekurze: pokud je vnořený blok, nejprve vyprázdni buff a pak zpracuj vnitřek
        if (isBlock(child)) {
          flushText(textBuf, el);
          textBuf = '';
          processBlock(child);
          return;
        }
        // Obyčejný inline bez class/style – přidej jeho text do bufferu
        textBuf += normText((child as HTMLElement).innerText || '');
      }
    });
    flushText(textBuf, el);
  };

  // Projdi přímé děti a rozlož blokové prvky v pořadí DOM
  Array.from(rich.childNodes).forEach((node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const txt = (node.textContent || '').trim();
      if (txt) out.push({ text: txt, classes: '', inline: false });
      return;
    }
    if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as Element;
      if (isBlockLike(el)) {
        processBlock(el);
      } else {
        // Neznámý inline kontejner – vezmi jeho text jako inline segment v rámci okolního bloku
        const txt = (el as HTMLElement).innerText || '';
        const cls = (el.getAttribute('class') || '').trim();
        const sty = el.getAttribute('style') || undefined;
        if (txt.trim()) out.push({ text: txt, classes: cls, style: sty, inline: true });
      }
    }
  });
  // Fallback: když nic nenašlo, vrať jeden segment z celého rich
  if (!out.length) {
    const txt = (rich.innerText || '').trim();
    if (txt) out.push({ text: txt, classes: '' });
  }
  return out;
}

// 🎮 Utility funkce pro speed controls
// Plovoucí ovladače rychlosti byly odstraněny – spravuje je výhradně ovládací panel v layoutu.

// 🎭 Debug utility pro vývojáře
export function toggleDebugMode(): void {
  document.body.classList.toggle('debug-mode');
  const isDebug = document.body.classList.contains('debug-mode');
  console.log(`🔧 Debug mode: ${isDebug ? 'ON' : 'OFF'}`);
}

// 🎪 Easter egg: Konami kód aktivace
let konamiSequence: string[] = [];
const konamiCode = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'KeyB', 'KeyA'];

export function initKonamiCode(): void {
  document.addEventListener('keydown', (e) => {
    konamiSequence.push(e.code);
    if (konamiSequence.length > konamiCode.length) {
      konamiSequence.shift();
    }
    
    if (konamiSequence.length === konamiCode.length && 
        konamiSequence.every((key, i) => key === konamiCode[i])) {
      document.body.classList.toggle('konami-activated');
      console.log('🎉 KONAMI CODE ACTIVATED! Welcome to the matrix... 😎');
      konamiSequence = []; // reset
    }
  });
}

// 🚀 Hlavní funkce pro setup speed controls
// setupTypewriterControls odstraněno – žádné automatické vkládání plovoucích tlačítek.

export async function startBodyTypingFromHtml(html: string, hostSelector = '#reader-body'): Promise<void> {
  const bodyHost = document.querySelector(hostSelector) as HTMLElement | null;
  if (!bodyHost) { console.log('typewriter: no bodyHost'); return; }
  const ds = (bodyHost as any).dataset as Record<string, string | undefined>;
  if (ds.twBusy === '1') { console.log('typewriter: external busy, skipping'); return; }
  ds.twBusy = '1';

  // vlož/nahraď externí rich obsah
  let ext = bodyHost.querySelector('.rich-external') as HTMLElement | null;
  if (!ext) {
    ext = document.createElement('div');
    ext.className = 'rich-hidden rich-external';
    (ext.style as any).display = 'none';
    bodyHost.appendChild(ext);
  }
  ext.innerHTML = html || '';

  // 🎯 Označit, že components.css styly by se měly používat
  bodyHost.classList.add('components-loaded');
  
  // 💀 BRUTÁLNÍ řešení: Dynamicky přidej components.css styly s vyšší prioritou
  const ensureComponentsStyles = () => {
    const existingStyle = document.getElementById('components-css-override');
    if (existingStyle) return; // už je tam
    
    const style = document.createElement('style');
    style.id = 'components-css-override';
    style.textContent = `
      /* 🔥 BRUTÁLNÍ override - přesné kopie stylů z components.css s vyšší prioritou */
      
      /* LOG styly z components.css */
      .SYNTHOMAREADER .log {
        position: relative !important;
        color: var(--text-primary) !important;
        text-transform: uppercase !important;
        font-family: 'Text03b', monospace !important;
        font-weight: 700 !important;
        text-shadow: -1px 0 4px 0px var(--accent-error), 1px 0 8px 0px var(--accent-error), 0px 0 12px 0px var(--accent-error) !important;
        font-size: calc(1.15rem * var(--font-size-multiplier)) !important;
        line-height: 1.5 !important;
        margin: 0 .1rem !important;
        padding: .5rem 1rem 0 .5rem !important;
        z-index: 10 !important;
        display: block !important;
      }
      
      .SYNTHOMAREADER .log::before {
        content: '' !important;
        position: absolute !important;
        left: -0.5rem !important;
        width: 4px !important;
        height: 100% !important;
        border-radius: 2px !important;
        background: rgb(0, 255, 255, 0) !important;
        box-shadow: -1px 0 4px 0px #f00, 1px 0 8px 0px #f00, 0px 0 12px 0px #ff0 !important;
        animation: border-glow 2.6s infinite cubic-bezier(.8,0,.23,1.1) !important;
        z-index: 2 !important;
        pointer-events: none !important;
        opacity: 0.6 !important;
      }
      
      /* DIALOG styly z components.css */
      .SYNTHOMAREADER .dialog {
        position: relative !important;
        color: var(--text-primary) !important;
        text-shadow: 0 0 5px var(--glow-secondary), 0 0 10px var(--glow-secondary) !important;
        font-family: 'Text03i', monospace !important;
        font-weight: bold !important;
        font-size: calc(1.15rem * var(--font-size-multiplier)) !important;
        line-height: 1.5 !important;
        text-align: left !important;
        margin: 0rem !important;
        z-index: 10 !important;
        display: block !important;
      }
      
      .SYNTHOMAREADER .dialog::before {
        content: '' !important;
        position: absolute !important;
        left: -0.5rem !important;
        width: 4px !important;
        height: 100% !important;
        border-radius: 2px !important;
        background: rgb(0, 255, 255, 0) !important;
        box-shadow: -1px 0 4px 0px #0ff, 1px 0 8px 0px #f0f, 0px 0 12px 0px #0ff !important;
        animation: border-glow 2.6s infinite cubic-bezier(.8,0,.23,1.1) !important;
        z-index: 2 !important;
        pointer-events: none !important;
        opacity: 0.6 !important;
      }
      
      /* TEXT styly z components.css */
      .SYNTHOMAREADER .text {
        position: relative !important;
        color: var(--text-primary) !important;
        text-shadow: 0 0 2px var(--glow-primary), 0 0 4px var(--glow-secondary) !important;
        font-family: 'Text03', monospace !important;
        font-size: calc(1.15rem * var(--font-size-multiplier)) !important;
        line-height: 1.5 !important;
        text-align: left !important;
        margin: 0rem !important;
        z-index: 10 !important;
        display: block !important;
      }
      
      .SYNTHOMAREADER .text::before {
        content: '' !important;
        position: absolute !important;
        left: -0.5rem !important;
        width: 4px !important;
        height: 100% !important;
        border-radius: 2px !important;
        background: rgb(0, 255, 255, 0) !important;
        box-shadow: -1px 0 4px 0px #0ff, 1px 0 8px 0px #0ff, 0px 0 12px 0px #00f !important;
        animation: border-glow 2.6s infinite cubic-bezier(.8,0,.23,1.1) !important;
        z-index: 2 !important;
        pointer-events: none !important;
        opacity: 0.6 !important;
      }
      
      /* TITLE styly z components.css */
      .SYNTHOMAREADER .title {
        position: relative !important;
        font-family: 'Synthoma', monospace !important;
        font-weight: 700 !important;
        color: var(--text-primary) !important;
        line-height: 1.4 !important;
        font-size: calc(1.8rem * var(--font-size-multiplier)) !important;
        text-align: center !important;
        text-shadow: 0 0 15px var(--glow-secondary), 0 0 20px var(--glow-primary) !important;
        margin: 0 .1rem !important;
        padding: .5rem 1rem .5rem .5rem !important;
        z-index: 10 !important;
        display: block !important;
      }
      
      .SYNTHOMAREADER .title::before {
        content: '' !important;
        position: absolute !important;
        left: -0.5rem !important;
        width: 4px !important;
        height: 100% !important;
        border-radius: 2px !important;
        background: rgb(0, 255, 255, 0) !important;
        box-shadow: -1px 0 4px 0px #0ff, 1px 0 8px 0px #ff00ff, 0px 0 12px 0px #faff00 !important;
        animation: border-glow 2.6s infinite cubic-bezier(.8,0,.23,1.1) !important;
        z-index: 2 !important;
        pointer-events: none !important;
        opacity: 0.6 !important;
      }
      
      /* 💀 ALARM-EMOTE styly - blikající efekty pro spany */
      .SYNTHOMAREADER .alarm-emote {
        display: inline-block !important;
        color: var(--accent-error, #ff3355) !important;
        text-shadow: 0 0 6px currentColor, 0 0 14px var(--glow-secondary) !important;
        animation: alarm-pulse 1s steps(2, start) infinite !important;
        transform: none !important;
        position: relative !important;
        font-weight: bold !important;
        filter: brightness(1.2) !important;
      }
      
      /* 🔧 Border-glow animace - BEZ transform aby text neposkakoval */
      @keyframes border-glow {
        0%, 100% { 
          opacity: 0.6;
          box-shadow: -1px 0 4px 0px currentColor, 1px 0 8px 0px currentColor, 0px 0 12px 0px currentColor;
        }
        50% { 
          opacity: 1;
          box-shadow: -2px 0 8px 0px currentColor, 2px 0 16px 0px currentColor, 0px 0 24px 0px currentColor;
        }
      }
      
      /* 🔥 Alarm-pulse animace pro blikající efekt */
      @keyframes alarm-pulse {
        0%, 100% { 
          filter: brightness(1); 
          opacity: 0.35; 
          text-shadow: 0 0 6px currentColor, 0 0 14px var(--glow-secondary);
        }
        50% { 
          filter: brightness(2.2); 
          opacity: 1; 
          text-shadow: 0 0 12px currentColor, 0 0 24px var(--glow-secondary), 0 0 36px currentColor;
        }
      }
      
      /* 🛑 VYPNI všechny glitch animace v čtečce - způsobují poskakování! */
      .SYNTHOMAREADER .glitchy,
      .SYNTHOMAREADER .glitch-master,
      .SYNTHOMAREADER .glitching,
      .SYNTHOMAREADER [class*="glitch"] {
        animation: none !important;
        transform: none !important;
        text-shadow: inherit !important;
      }
      
      /* 🔧 Vypni jen problematické animace, ale zachovej viditelnost textu */
      .SYNTHOMAREADER .glitchy,
      .SYNTHOMAREADER .glitch-master,
      .SYNTHOMAREADER .glitching {
        animation-name: none !important;
      }
      
      /* 🎯 Zajisti viditelnost textu */
      .SYNTHOMAREADER .log,
      .SYNTHOMAREADER .dialog,
      .SYNTHOMAREADER .text,
      .SYNTHOMAREADER .title {
        opacity: 1 !important;
        visibility: visible !important;
        display: block !important;
      }
      
      /* 🎯 Ale ponech jen border-glow a alarm-pulse */
      .SYNTHOMAREADER .log::before,
      .SYNTHOMAREADER .dialog::before,
      .SYNTHOMAREADER .text::before,
      .SYNTHOMAREADER .title::before {
        animation: border-glow 2.6s infinite cubic-bezier(.8,0,.23,1.1) !important;
      }
      
      .SYNTHOMAREADER .alarm-emote {
        animation: alarm-pulse 1s steps(2, start) infinite !important;
      }
    `;
    document.head.appendChild(style);
    console.log('🔥 Components.css override styles injected!');
  };
  
  ensureComponentsStyles();
  
  // připrav zobrazovací kontejner
  let container = bodyHost.querySelector('.noising-text') as HTMLElement | null;
  const appendMode = hostSelector === '#reader-extra';
  if (appendMode) {
    // V append módu nikdy nečisti existující obsah; vytvoř nový wrapper pro tento běh
    const wrapper = document.createElement('div');
    wrapper.className = 'tw-block';
    container = document.createElement('span');
    container.className = 'noising-text';
    wrapper.appendChild(container);
    bodyHost.appendChild(wrapper);
  } else {
    if (!container) {
      container = document.createElement('span');
      container.className = 'noising-text';
      bodyHost.appendChild(container);
    } else {
      container.textContent = '';
    }
  }
  (container.style as any).whiteSpace = 'pre-wrap';
  (container.style as any).display = 'block';

  // Nově: segmenty z bohatého HTML, abychom přenesli třídy/styly už při psaní
  const segments = extractSegmentsFromRichHost(bodyHost);
  let lines = segments.length ? segments.map(s => s.text) : extractTextFromRichHost(bodyHost).split(/\n/);
  if (!segments.length && lines.length <= 1 && (lines[0]?.length || 0) > 300) {
    lines = lines[0].split(/\n|(?<=[\.?!…])\s+(?=[A-ZÁ-Ž0-9„(])/u);
  }
  const lengths = lines.map(l => l.length || 1);
  const totalChars = lengths.reduce((a,b)=>a+b,0) || 1;
  // 🎯 Vylepšená kalkulace rychlosti s user preferencemi
  const computeTotalDuration = () => {
    const mw = document.getElementById('manifest-container');
    let baseDuration = 24000; // default fallback
    
    if (mw) {
      const cs = getComputedStyle(mw);
      const durVar = cs.getPropertyValue('--typewriter-duration').trim();
      if (durVar.endsWith('ms')) baseDuration = parseFloat(durVar) * 3.5;
      else if (durVar.endsWith('s')) baseDuration = parseFloat(durVar) * 1000 * 3.5;
    }
    
    // 🚀 Aplikuj speed multiplier z localStorage nebo default
    const speedPref = localStorage.getItem('synthoma-typewriter-speed') || 'normal';
    const speedMultipliers = {
      'instant': 0.1,
      'fast': 0.4,
      'normal': 1.0,
      'slow': 2.5
    };
    
    return Math.max(500, baseDuration * (speedMultipliers[speedPref as keyof typeof speedMultipliers] || 1.0));
  };
  const totalDuration = computeTotalDuration();

  const scrollTerminalBottom = () => {
    // Auto-scroll vypnuto ve výchozím stavu. Zapni přes localStorage 'synthoma-autoscroll' = '1' nebo body.dataset.autoscroll = '1'
    try {
      const ls = (typeof localStorage !== 'undefined') ? localStorage.getItem('synthoma-autoscroll') : null;
      const enable = (ls === '1') || (document?.body?.dataset?.autoscroll === '1');
      if (!enable) return;
      window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
    } catch {}
  };

  const startLine = (idx: number, onAllDone: () => void) => {
    if (idx >= lines.length) { onAllDone(); return; }
    const text = lines[idx];
    const lineEl = document.createElement('span');
    (lineEl.style as any).whiteSpace = 'pre-wrap';
    // default blokově, ale pokud segment říká inline, tak inline
    const seg = segments[idx];
    const isInline = !!(seg && seg.inline);
    (lineEl.style as any).display = isInline ? 'inline' : 'block';
    // Přenes třídy/styly z původního segmentu (efekty hned během psaní)
    if (seg) {
      if (seg.classes) lineEl.className = seg.classes + ' tw-line';
      if (seg.style) {
        try {
          // sloučit bez zničení již nastaveného display/whiteSpace
          (lineEl as HTMLElement).style.cssText += ';' + seg.style;
          // a jistota, že klíčové vlastnosti zůstanou
          (lineEl.style as any).whiteSpace = 'pre-wrap';
          (lineEl.style as any).display = isInline ? 'inline' : 'block';
        } catch {}
      }
    }
    
    // 🎯 Zjisti speed preference jednou pro celou funkci
    const speedPref = localStorage.getItem('synthoma-typewriter-speed') || 'normal';
    
    // Přidej speed class pro instant mód
    if (speedPref === 'instant') {
      lineEl.classList.add('typewriter-instant');
    }
    // runTypewriter očekává uvnitř hosta element .noising-text
    const inner = document.createElement('span');
    inner.className = 'noising-text';
    lineEl.appendChild(inner);
    container!.appendChild(lineEl);
    scrollTerminalBottom();
    const share = lengths[idx] / totalChars;
    let dur = Math.max(250, Math.round(totalDuration * share));
    const perChar = Math.min(5000, Math.max(250, (text.length || 1) * 22));
    dur = Math.min(dur, perChar);
    
    // 💀 Adaptivní rychlost podle typu obsahu
    if (seg?.classes) {
      if (seg.classes.includes('log')) dur *= 0.7; // logy rychleji
      if (seg.classes.includes('dialog')) dur *= 1.2; // dialogy pomaleji pro dramatičnost
      if (seg.classes.includes('title')) dur *= 1.5; // titulky s důrazem
    }
    if (!text || text.trim() === '') {
      window.setTimeout(() => startLine(idx + 1, onAllDone), 10);
      return;
    }
    
    // 🚀 Instant mód: přeskoč typewriter a zobraz rovnou
    if (speedPref === 'instant') {
      inner.textContent = text;
      scrollTerminalBottom();
      window.setTimeout(() => startLine(idx + 1, onAllDone), 50);
      return;
    }
    const cancel = runTypewriter({
      text,
      host: lineEl,
      getDurationMs: () => dur,
      onStart: () => { /* noop */ return; },
      onDone: () => { scrollTerminalBottom(); startLine(idx + 1, onAllDone); }
    });
    void cancel;
  };

  // 🎮 Auto-setup controls při prvním spuštění
  // Auto-setup plovoucích ovladačů odstraněn – používáme pouze ovládací panel.
  
  console.log('typewriter: external start', { lines: lines.length, speed: localStorage.getItem('synthoma-typewriter-speed') || 'normal' });
  startLine(0, () => {
    console.log('typewriter: external done');
    try { ds.twBusy = '0'; } catch {}
    // Po dopsání nahraď skeleton za skutečné bohaté HTML
    try {
      const rich = bodyHost.querySelector('.rich-hidden') as HTMLElement | null;
      if (rich) {
        const sg = (window as any).startGlitching;
        const tmp = document.createElement('div');
        tmp.innerHTML = rich.innerHTML;
        const batchSize = 20;
        const nodes: ChildNode[] = Array.from(tmp.childNodes);
        const frag = document.createDocumentFragment();

        const flushFrag = (target: HTMLElement) => {
          target.appendChild(frag);
          try {
            if (typeof sg === 'function') {
              const recent = target.querySelectorAll('.glitch-master, .glitching');
              if (recent && recent.length) sg('.glitching');
            }
          } catch {}
        };

        const processBatchInto = (target: HTMLElement) => {
          let count = 0;
          while (nodes.length && count < batchSize) {
            const n = nodes.shift()!;
            frag.appendChild(n);
            count++;
          }
          flushFrag(target);
          if (nodes.length) {
            if ('requestIdleCallback' in window) {
              (window as any).requestIdleCallback(() => processBatchInto(target), { timeout: 32 });
            } else {
              setTimeout(() => processBatchInto(target), 16);
            }
          }
        };

        if (appendMode) {
          // V append módu pracuj pouze v rámci lokálního wrapperu .tw-block
          const wrapper = container.parentElement && (container.parentElement as HTMLElement).classList.contains('tw-block')
            ? (container.parentElement as HTMLElement)
            : null;
          const target = wrapper || bodyHost;
          try { container.remove(); } catch {}
          processBatchInto(target);
        } else {
          // V normálním módu nahraď celý host
          try { bodyHost.replaceChildren(); } catch { bodyHost.innerHTML = ''; }
          processBatchInto(bodyHost);
        }
      }
    } catch {}
  });
}

export async function typeExternalInfo(): Promise<void> {
  const url = '/data/SYNTHOMAINFO.html';
  const res = await fetch(url, { cache: 'no-store' });
  const html = await res.text();
  const baseUrl = '/data/';
  const bodyHtml = installChapterAssetsAndGetBody(html, baseUrl, 'info');
  await startBodyTypingFromHtml(bodyHtml);
}

function setupBooksHandlers() {
  const container = document.querySelector('#reader-content') as HTMLElement | null;
  if (!container) return;
  const d = (container as any).dataset as Record<string, string|undefined>;
  if (d.booksHandlers) return;
  d.booksHandlers = '1';
  // Helper: odemkni navigaci a odstraň disable/selected z odkazů
  (container as any).resetNavState = function resetNavState(){
    try { (container as any).dataset.navLocked = '0'; } catch {}
    try {
      container.querySelectorAll('a.book-link, a.chapter-link').forEach((el:any)=>{
        el.removeAttribute('aria-disabled');
        el.classList.remove('disabled');
        el.classList.remove('selected');
        (el as HTMLAnchorElement).style.pointerEvents = '';
      });
    } catch {}
  };
  container.addEventListener('click', (ev) => {
    const target = ev.target as HTMLElement | null;
    if (!target) return;
    const a = target.closest('a') as HTMLAnchorElement | null;
    if (!a) return;
    if (a.classList.contains('book-link')) {
      ev.preventDefault();
      if (d.navLocked === '1') return;
      const book = a.getAttribute('data-book') || '';
      if (!book) return;
      // Zamkni navigaci a zvýrazni volbu
      d.navLocked = '1';
      try {
        container.querySelectorAll('a.book-link, a.chapter-link').forEach((el:any)=>{
          el.setAttribute('aria-disabled','true');
          el.classList.add('disabled');
          (el as HTMLAnchorElement).style.pointerEvents = 'none';
        });
        a.classList.add('selected');
      } catch {}
      try { (container as any).dataset.currentBook = book; } catch {}
      typeBooksList(book).catch(() => { /* ignore */ });
    } else if (a.classList.contains('chapter-link')) {
      ev.preventDefault();
      if (d.navLocked === '1') return;
      const book = d.currentBook || a.getAttribute('data-book') || '';
      const file = a.getAttribute('data-file') || '';
      if (!file) return;
      // Zamkni navigaci a zvýrazni volbu
      d.navLocked = '1';
      try {
        container.querySelectorAll('a.book-link, a.chapter-link').forEach((el:any)=>{
          el.setAttribute('aria-disabled','true');
          el.classList.add('disabled');
          (el as HTMLAnchorElement).style.pointerEvents = 'none';
        });
        a.classList.add('selected');
      } catch {}
      if (book) { loadChapter(book, file).catch(() => { /* ignore */ }); }
    }
  }, true);
}

// --- Interaktivní příběh: volby a bloky ---
function ensureStoryCache(root: HTMLElement): HTMLElement {
  let cache = root.querySelector('#story-cache') as HTMLElement | null;
  if (!cache) {
    cache = document.createElement('div');
    cache.id = 'story-cache';
    (cache.style as any).display = 'none';
    root.appendChild(cache);
  }
  return cache;
}

function setupInteractiveHandlers(): void {
  const container = document.querySelector('#reader-content') as HTMLElement | null;
  if (!container) return;
  const d = (container as any).dataset as Record<string, string|undefined>;
  if ((d as any).interactiveHandlers) return;
  (d as any).interactiveHandlers = '1';
  container.addEventListener('click', (ev) => {
    const target = ev.target as HTMLElement | null;
    if (!target) return;
    const a = target.closest('a.choice-link') as HTMLAnchorElement | null;
    if (!a) return;
    ev.preventDefault();
    // Pokud je box již zamknut, ignoruj
    const box = a.closest('.choice-box') as HTMLElement | null;
    if (!box) return;
    if (box.getAttribute('data-locked') === '1') return;
    // Zamkni všechny v boxu a vyznač volbu
    try {
      const links = Array.from(box.querySelectorAll('a.choice-link')) as HTMLAnchorElement[];
      links.forEach((el)=>{
        el.setAttribute('aria-disabled','true');
        el.classList.add('disabled');
        el.style.pointerEvents = 'none';
      });
      a.classList.add('selected');
      box.setAttribute('data-locked','1');
    } catch {}
    // Najdi další blok podle data-next
    const rawNext = a.getAttribute('data-next') || '';
    if (!rawNext) { console.warn('🪦 Žádný data-next. Volba vede do prázdna.'); return; }
    const nextId = rawNext.replace(/^#+/, '');
    const w = window as any;
    w.__synthomaStory = w.__synthomaStory || { visited: new Set<string>(), current: '' };
    const visited: Set<string> = w.__synthomaStory.visited;
    if (visited.has(nextId)) {
      console.warn(`🧠 Smyčka detekována: blok ${nextId} už jsme žvýkali. Ignoruju, než z toho vznikne nekonečný glitch.`);
      return;
    }
    visited.add(nextId);
    // Vytáhni blok z cache a appendně přepiš do #reader-extra přes typewriter
    const root = document.querySelector('#reader-content') as HTMLElement | null;
    if (!root) return;
    const cache = root.querySelector('#story-cache') as HTMLElement | null;
    if (!cache) { console.warn('🧊 Story cache chybí.'); return; }
    const block = cache.querySelector(`section.story-block#${CSS.escape(nextId)}`) as HTMLElement | null;
    if (!block) { console.warn('🧱 Blok nenalezen:', nextId); return; }
    const html = block.outerHTML;
    startBodyTypingFromHtml(html, '#reader-extra').catch(()=>{});
  }, true);
}

async function startInteractiveStory(book: string, file: string, bodyHtml: string): Promise<void> {
  const root = document.querySelector('#reader-content') as HTMLElement | null;
  if (!root) return;
  const cache = ensureStoryCache(root);
  cache.innerHTML = bodyHtml || '';
  const first = cache.querySelector('section.story-block#b1') as HTMLElement | null
    || cache.querySelector('section.story-block') as HTMLElement | null;
  if (!first) {
    console.warn('🪦 Nebyly nalezeny žádné story-block sekce, padám zpět na normální režim.');
    await startBodyTypingFromHtml(bodyHtml, '#reader-extra');
    return;
  }
  try {
    const w = window as any;
    w.__synthomaStory = { visited: new Set<string>(), current: first.id || 'b1', book, file };
    if (first.id) w.__synthomaStory.visited.add(first.id);
  } catch {}
  setupInteractiveHandlers();
  await startBodyTypingFromHtml(first.outerHTML, '#reader-extra');
}

async function loadChapter(book: string, file: string): Promise<void> {
  const url = `/books/${encodeURIComponent(book)}/${encodeURIComponent(file)}`;
  const baseUrl = `/books/${encodeURIComponent(book)}/`;
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const html = await res.text();

  // Nainstaluj CSS/font assety z kapitoly do <head> a vrať čisté body HTML
  const key = `chapter:${book}/${file}`;
  const bodyHtml = installChapterAssetsAndGetBody(html, baseUrl, key);
  // Detekce interaktivního příběhu pomocí section.story-block
  if (/<section[^>]*class=["'][^"']*\bstory-block\b/i.test(bodyHtml)) {
    console.log('🎮 Interaktivní kapitola detekována – spouštím story flow');
    await startInteractiveStory(book, file, bodyHtml);
  } else {
    await startBodyTypingFromHtml(bodyHtml, '#reader-extra');
  }
}

export async function typeBooksList(book?: string): Promise<void> {
  // Globální guard přes window – přežije i Fast Refresh
  const w = (typeof window !== 'undefined' ? (window as any) : {}) as any;
  w.__synthomaUI = w.__synthomaUI || { booksRendered: false, chaptersRendered: {} as Record<string, boolean> };
  // reentrancy guard: pokud externí typewriter běží, nezkoušej spouštět další
  const bodyHost = document.querySelector('#reader-extra') as HTMLElement | null || document.querySelector('#reader-body') as HTMLElement | null;
  if (bodyHost) {
    const ds = (bodyHost as any).dataset as Record<string, string | undefined>;
    if (ds.twBusy === '1') { console.log('typewriter: books ignored, external busy'); return; }
  }
  const root = document.querySelector('#reader-content') as HTMLElement | null;
  const rds = (root as any)?.dataset as Record<string, string | undefined> | undefined;
  if (!book) {
    if (rds?.booksBusy === '1') { console.log('typewriter: books render in-flight, skipping'); return; }
    if (rds) rds.booksBusy = '1';
  } else {
    if (rds?.chaptersBusy === '1') { console.log('typewriter: chapters render in-flight, skipping'); return; }
    if (rds) rds.chaptersBusy = '1';
  }
  if (!book) {
    // Pokud už jsme knihy renderovali, nereplikuj – jen zkus reaktivovat odkazy
    if (w.__synthomaUI.booksRendered) {
      console.log('typewriter: books already rendered (window guard), re-enable links');
      try {
        const cont = document.querySelector('#reader-content') as any;
        if (cont && typeof cont.resetNavState === 'function') cont.resetNavState();
        else if (cont) { cont.dataset.navLocked = '0'; }
      } catch {}
      // Deduplikace: nech první, ostatní odstraň
      try {
        const nodes = Array.from(document.querySelectorAll('#reader-extra .books-list')) as HTMLElement[];
        nodes.forEach((el,i)=>{ if (i>0) el.parentElement?.removeChild(el); else el.setAttribute('data-scope','books'); });
      } catch {}
      setupBooksHandlers();
      if (rds) rds.booksBusy = '0';
      return;
    }
    // Normalizuj existující seznam knih – pokud existuje, použij ho a neappenduj nový
    const existing = document.querySelector('#reader-extra .books-list') as HTMLElement | null;
    if (existing) {
      existing.setAttribute('data-scope','books');
      console.log('typewriter: books list found, not appending duplicate');
      try {
        const cont = document.querySelector('#reader-content') as any;
        if (cont && typeof cont.resetNavState === 'function') cont.resetNavState();
        else if (cont) { cont.dataset.navLocked = '0'; }
      } catch {}
      // Jistá deduplikace
      try {
        const lists = Array.from(document.querySelectorAll('#reader-extra .books-list')) as HTMLElement[];
        lists.forEach((el,i)=>{ el.setAttribute('data-scope','books'); if (i>0) el.parentElement?.removeChild(el); });
      } catch {}
      setupBooksHandlers();
      w.__synthomaUI.booksRendered = true;
      if (rds) rds.booksBusy = '0';
      return;
    }
    const res = await fetch('/api/books', { cache: 'no-store' });
    const data = await res.json();
    if (!data?.ok) throw new Error(data?.error || 'Unknown');
    const items = (data.items as {name:string,type:'dir'|'file',size:number}[]);
    const books = items.filter(it => it.type === 'dir');
    const list = books.map(it => `<div>📖 <a href="#" class="book-link" data-book="${it.name}">${it.name}</a></div>`).join('');
    const html = `
      <h3>Knihovna</h3>
      <div class="books-list" data-scope="books">
        ${list || '<em>Žádné knihy</em>'}
      </div>
    `;
    // Resetni nav lock a reaktivuj odkazy: teď se teprve vybírá, takže odkazy musí být aktivní
    try {
      const container = document.querySelector('#reader-content') as HTMLElement | null;
      if (container) {
        (container as any).dataset.navLocked = '0';
        const contAny = container as any;
        if (typeof contAny.resetNavState === 'function') contAny.resetNavState();
      }
    } catch {}
    await startBodyTypingFromHtml(html, '#reader-extra');
    // po připsání označ scope a deduplikuj jistotně
    try {
      const lists = Array.from(document.querySelectorAll('#reader-extra .books-list')) as HTMLElement[];
      lists.forEach((el,i)=>{ el.setAttribute('data-scope','books'); if (i>0) el.parentElement?.removeChild(el); });
    } catch {}
    setupBooksHandlers();
    w.__synthomaUI.booksRendered = true;
    if (rds) rds.booksBusy = '0';
    return;
  }

  // List chapters for selected book
  const res = await fetch(`/api/books?book=${encodeURIComponent(book)}`, { cache: 'no-store' });
  const data = await res.json();
  if (!data?.ok) throw new Error(data?.error || 'Unknown');
  const items = (data.items as {name:string,type:'dir'|'file',size:number}[]);
  const chapters = items.filter(it => it.type === 'file' && /\.html?$/i.test(it.name));
  const chapterList = chapters.map(it => {
    const title = it.name.replace(/\.(html?)$/i, '')
      .replace(/[_-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    return `<div> <a href="#" class="chapter-link" data-file="${it.name}">${title}</a></div>`;
  }).join('');
  // Pokud už existuje seznam kapitol pro tuto knihu, nespamuj znovu
  const chaptersScopeSel = `#reader-extra .books-list[data-scope="chapters:${CSS.escape(book)}"]`;
  if (document.querySelector(chaptersScopeSel) || w.__synthomaUI.chaptersRendered[book]) {
    console.log('typewriter: chapters list already present for book', book);
  } else {
    const html = `
      <h2 class="title">${book}</h2>
      <div><h3 class="books-list" data-scope="chapters:${book}">${chapterList || '<em>Žádné kapitoly</em>'}</h3></div>
    `;
    await startBodyTypingFromHtml(html, '#reader-extra');
    // Deduplikuj případné dvojáky pro stejnou knihu
    try {
      const lists = Array.from(document.querySelectorAll(`#reader-extra .books-list[data-scope^="chapters:"]`)) as HTMLElement[];
      const keepFirst = lists.find(el => el.getAttribute('data-scope') === `chapters:${book}`);
      lists.forEach(el => {
        const scope = el.getAttribute('data-scope') || '';
        if (scope === `chapters:${book}` && el !== keepFirst) el.parentElement?.removeChild(el);
      });
    } catch {}
    w.__synthomaUI.chaptersRendered[book] = true;
  }
  // Ulož kontext vybrané knihy pro kliky na kapitoly
  const reader = document.querySelector('#reader-content') as HTMLElement | null;
  if (reader) { try { (reader as any).dataset.currentBook = book; } catch {} }
  setupBooksHandlers();
  // Pro jistotu odemkni navigaci (kapitoly jsou volba, ale chceme aktivní hovery)
  try {
    const cont = document.querySelector('#reader-content') as any;
    if (cont && typeof cont.resetNavState === 'function') cont.resetNavState();
    else if (cont) { cont.dataset.navLocked = '0'; }
  } catch {}
  if (rds) rds.chaptersBusy = '0';
}

/**
 * Runs the char-by-char typewriter with glitchy searcher and integrates with shining/noising helpers on window.
 * Mirrors the previous implementation from page.tsx but packaged for reuse.
 */
export function runTypewriter(opts: TypewriterOptions): CancelFn {
  const { text, host, getDurationMs, onStart, onDone } = opts;
  const prefersReduced = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const animationsDisabled = typeof document !== 'undefined' && document.body?.classList.contains('no-animations');
  const span = host.querySelector('.noising-text') as HTMLElement | null;
  if (!span) return () => { /* noop */ return; };

  const pending: number[] = [];
  let typingId: number | null = null;

  const clearAll = () => {
    if (typingId) { try { clearTimeout(typingId); } catch {} typingId = null; }
    while (pending.length) { const id = pending.pop(); if (typeof id === 'number') try { clearTimeout(id); } catch {} }
  };

  // If animations are off, render immediately
  if (prefersReduced || animationsDisabled) {
    if (onStart) try { onStart(); } catch {}
    span.textContent = '';
    const chars = text.split('');
    for (const ch of chars) {
      const el = document.createElement('span');
      el.className = 'tw-char noising-char';
      el.textContent = ch;
      if (ch.trim().length > 0) el.classList.add('noising-static');
      span.appendChild(el);
    }
    if (onDone) try { onDone(); } catch {}
    return clearAll;
  }

  // Normal animated flow
  if (onStart) try { onStart(); } catch {}
  span.textContent = '';
  const tokens = text.split('');
  // start shining engine so it can adopt settled chars
  try {
    const w: any = window as any;
    if (typeof w.startShinning === 'function') w.startShinning();
  } catch {}

  let totalMs = 7200;
  try {
    if (getDurationMs) totalMs = Math.max(100, getDurationMs());
  } catch {}
  const perStep = Math.max(12, Math.round(totalMs / Math.max(1, tokens.length)));
  const GLITCH_CHARS = "!@#$%^&*_-+=?/|<>[]{};:~NYHSMT#¤%&@§÷×¤░▒▓█▄▀●◊O|/_^-~.*+";

  let idx = 0;
  const tick = () => {
    if (!span) return;
    const ch = tokens[idx++] || '';
    const node = document.createElement('span');
    node.className = 'tw-char';

    if (ch.trim().length > 0) {
      const rand0 = GLITCH_CHARS[(Math.random() * GLITCH_CHARS.length) | 0] || ch;
      node.textContent = rand0;
      const frame = Math.max(18, Math.min(48, Math.round(perStep / 3)));
      const steps = Math.max(2, Math.min(5, Math.round(perStep / frame)));
      for (let s = 0; s < steps; s++) {
        const id = window.setTimeout(() => {
          if (!node) return;
          const r = GLITCH_CHARS[(Math.random() * GLITCH_CHARS.length) | 0] || ch;
          node.textContent = r;
        }, s * frame) as unknown as number;
        pending.push(id);
      }
      const finalId = window.setTimeout(() => {
        if (!node) return;
        node.textContent = ch;
        const prefersReduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const animationsDisabled = document.body && document.body.classList.contains('no-animations');
        if (!prefersReduced && !animationsDisabled) {
          node.classList.add('noising-char');
          node.classList.add('noising');
          try { node.classList.add('noising-burst'); window.setTimeout(() => { try { node.classList.remove('noising-burst'); } catch {} }, 200); } catch {}
        }
      }, steps * frame) as unknown as number;
      pending.push(finalId);
    } else {
      node.textContent = ch;
    }

    if (ch.trim().length > 0) {
      node.classList.add('tw-glitch');
      window.setTimeout(() => { node.classList.remove('tw-glitch'); }, Math.max(80, Math.min(180, Math.round(perStep*0.9))));
    }
    span.appendChild(node);
    if (ch.trim().length > 0 && Math.random() < 0.10) {
      node.classList.add('tw-split');
      window.setTimeout(() => { node.classList.remove('tw-split'); }, 120);
    }
    if (Math.random() < 0.06) {
      span.classList.add('tw-blip');
      window.setTimeout(() => { span.classList.remove('tw-blip'); }, 120);
    }

    if (idx < tokens.length) {
      typingId = window.setTimeout(tick, perStep) as unknown as number;
    } else {
      try { span.classList.remove('tw-blip'); } catch {}
      while (pending.length) { const id = pending.pop(); if (typeof id === 'number') try { clearTimeout(id); } catch {} }
      try {
        const prefersReduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const animationsDisabled = document.body && document.body.classList.contains('no-animations');
        const chars = text.split('');
        let nodes = Array.from(span.querySelectorAll('.tw-char')) as HTMLElement[];
        for (let i=0;i<chars.length;i++){
          const ch = chars[i] || '';
          let el = nodes[i];
          if (!el){ el = document.createElement('span'); el.className = 'tw-char'; span.appendChild(el); }
          el.textContent = ch;
          el.classList.remove('tw-glitch','tw-split','flickering');
          if (!prefersReduced && !animationsDisabled && ch.trim().length>0) {
            el.classList.add('noising-char','noising');
          } else {
            el.classList.remove('noising');
            el.classList.add('noising-char');
            if (ch.trim().length > 0) el.classList.add('noising-static');
          }
          if (ch.trim().length > 0) {
            el.classList.add('noising-burst');
            window.setTimeout(() => { try { el.classList.remove('noising-burst'); } catch {} }, 200);
          }
        }
        nodes = Array.from(span.querySelectorAll('.tw-char')) as HTMLElement[];
        for (let j=nodes.length-1; j>=chars.length; j--){ nodes[j].remove(); }
      } catch {}
      try {
        const w: any = window as any;
        if (typeof w.startShinning === 'function') w.startShinning();
      } catch {}
      try {
        const w: any = window as any;
        if (typeof w.startNoising === 'function') w.startNoising();
      } catch {}
      if (onDone) try { onDone(); } catch {}
      typingId = null;
    }
  };

  typingId = window.setTimeout(tick, Math.max(10, Math.round(perStep))) as unknown as number;
  return clearAll;
}
